#pragma once
#include <string>
#include <iostream>
#include "Parcela.h"
#include "Usuario.h"
#include "Estructura_Conversion.h"
using namespace std;
class Consulta:public Usuario, public Parcela{
private:
	int idConsulta;
	string detalle;
public:
	Consulta(void);
	void insertaridConsulta(int);
	int devolveridConsulta();
	void insertardetalle(string);
	string devolverdetalle();
	consulta ConvertiraStruct();
};


#pragma once
#include <iostream>
#include <string>
#include "Empresa.h"
#include "Estructura_Conversion.h"
#include "Clase_Archivo.h"
#include <msclr\marshal_cppstd.h>
namespace Semilla_V11 {
	using namespace msclr::interop;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form41
	/// </summary>
	public ref class Form41 : public System::Windows::Forms::Form
	{
	public:
		Form41(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form41()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtidEmpresa;
	private: System::Windows::Forms::TextBox^  txtNombreE;
	private: System::Windows::Forms::TextBox^  txtNit;
	private: System::Windows::Forms::Button^  Registrar_empresa;
	private: System::Windows::Forms::Button^  Mostrar_Empresa;
	private: System::Windows::Forms::DataGridView^  grilla_Empresa;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtidEmpresa = (gcnew System::Windows::Forms::TextBox());
			this->txtNombreE = (gcnew System::Windows::Forms::TextBox());
			this->txtNit = (gcnew System::Windows::Forms::TextBox());
			this->Registrar_empresa = (gcnew System::Windows::Forms::Button());
			this->Mostrar_Empresa = (gcnew System::Windows::Forms::Button());
			this->grilla_Empresa = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Empresa))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(117, 29);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(48, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Empresa";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(33, 75);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(62, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"ID Empresa";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(33, 107);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(88, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Nombre Empresa";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(33, 135);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(25, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"NIT";
			// 
			// txtidEmpresa
			// 
			this->txtidEmpresa->Location = System::Drawing::Point(104, 72);
			this->txtidEmpresa->Name = L"txtidEmpresa";
			this->txtidEmpresa->Size = System::Drawing::Size(100, 20);
			this->txtidEmpresa->TabIndex = 4;
			// 
			// txtNombreE
			// 
			this->txtNombreE->Location = System::Drawing::Point(104, 104);
			this->txtNombreE->Name = L"txtNombreE";
			this->txtNombreE->Size = System::Drawing::Size(100, 20);
			this->txtNombreE->TabIndex = 5;
			// 
			// txtNit
			// 
			this->txtNit->Location = System::Drawing::Point(104, 132);
			this->txtNit->Name = L"txtNit";
			this->txtNit->Size = System::Drawing::Size(100, 20);
			this->txtNit->TabIndex = 6;
			// 
			// Registrar_empresa
			// 
			this->Registrar_empresa->Location = System::Drawing::Point(52, 197);
			this->Registrar_empresa->Name = L"Registrar_empresa";
			this->Registrar_empresa->Size = System::Drawing::Size(75, 23);
			this->Registrar_empresa->TabIndex = 7;
			this->Registrar_empresa->Text = L"Registrar";
			this->Registrar_empresa->UseVisualStyleBackColor = true;
			this->Registrar_empresa->Click += gcnew System::EventHandler(this, &Form41::Registrar_empresa_Click);
			// 
			// Mostrar_Empresa
			// 
			this->Mostrar_Empresa->Location = System::Drawing::Point(159, 197);
			this->Mostrar_Empresa->Name = L"Mostrar_Empresa";
			this->Mostrar_Empresa->Size = System::Drawing::Size(75, 23);
			this->Mostrar_Empresa->TabIndex = 8;
			this->Mostrar_Empresa->Text = L"Mostrar";
			this->Mostrar_Empresa->UseVisualStyleBackColor = true;
			this->Mostrar_Empresa->Click += gcnew System::EventHandler(this, &Form41::Mostrar_Empresa_Click);
			// 
			// grilla_Empresa
			// 
			this->grilla_Empresa->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_Empresa->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {this->Column1, 
				this->Column2, this->Column3});
			this->grilla_Empresa->Location = System::Drawing::Point(262, 46);
			this->grilla_Empresa->Name = L"grilla_Empresa";
			this->grilla_Empresa->Size = System::Drawing::Size(240, 150);
			this->grilla_Empresa->TabIndex = 9;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"ID Empresa";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Nombre Empresa";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"NIT";
			this->Column3->Name = L"Column3";
			// 
			// Form41
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(564, 261);
			this->Controls->Add(this->grilla_Empresa);
			this->Controls->Add(this->Mostrar_Empresa);
			this->Controls->Add(this->Registrar_empresa);
			this->Controls->Add(this->txtNit);
			this->Controls->Add(this->txtNombreE);
			this->Controls->Add(this->txtidEmpresa);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form41";
			this->Text = L"Form41";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Empresa))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Registrar_empresa_Click(System::Object^  sender, System::EventArgs^  e) {
				 Clase_Archivo <empresa> em;
				 Empresa Em;
				 Em.insertaridEmpresa(System::Convert::ToInt32(txtidEmpresa->Text));
				 Em.insertarnombreEmpresa(marshal_as<std::string>(System::Convert::ToString(txtNombreE->Text)));
				 Em.insertarNIT(System::Convert::ToInt32(txtNit->Text));
				 string cadena = "Empresas";
				 em.ingresar(Em.ConvertiraStruct(),cadena);
			 }
private: System::Void Mostrar_Empresa_Click(System::Object^  sender, System::EventArgs^  e) {
			 Clase_Archivo <empresa> em;
			 empresa Em;
			 int i = 0, tam;
			 tam = em.tamano("Empresas");
			 grilla_Empresa->RowCount = tam;
			 for(i = 0; i < tam; i++){
				 Em = em.devolver_reg(i,"Empresas");
				 grilla_Empresa->Rows[i]->Cells[0]->Value=Em.idEmpresa;
				 grilla_Empresa->Rows[i]->Cells[1]->Value=marshal_as<System::String^>(Em.nombreEmpresa);
				 grilla_Empresa->Rows[i]->Cells[3]->Value=Em.NIT;
			 }
		 }
};
}

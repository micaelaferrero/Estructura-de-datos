#include "StdAfx.h"
#include "Parcela.h"
#include "Usuario.h"
#include "Semilla_Caracteristica.h"

Parcela::Parcela(void)
{
}
void Parcela::insertaridParcela(int c){
	idParcela = c;
}
int Parcela::devolveridParcela(){
	return idParcela;
}
void Parcela::insertararea(int c){
	area = c;
}
int Parcela::devolverarea(){
	return area;
}
void Parcela::insertartiempo(int c){
	tiempo = c;
}
int Parcela::devolvertiempo(){
	return tiempo;
}
parcela Parcela::ConvertiraStruct(){
	parcela P;
	P.idParcela = this->devolveridParcela();
	P.idSemilla = this->devolveridSemilla();
	P.idUsuario = this->devolverCodUsuario();
	P.Area = this->devolverarea();
	P.tiempo = this->devolvertiempo();
	return P;
}
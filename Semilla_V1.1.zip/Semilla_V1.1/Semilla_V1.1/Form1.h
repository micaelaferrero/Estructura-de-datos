#pragma once
#include "stdafx.h"
#include "Form2.h"
#include "Form3.h"
#include "Form4.h"
#include "Form41.h"
#include "Form5.h"
#include "Form6.h"

namespace Semilla_V11 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  Insertar_Usuario;
	private: System::Windows::Forms::Button^  Insertar_Semilla;
	private: System::Windows::Forms::Button^  Insertar_Parcela;
	private: System::Windows::Forms::Button^  Registrar_Empresa;
	private: System::Windows::Forms::Button^  Registrar_Asesor;
	private: System::Windows::Forms::Button^  Insertar_Consulta;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->Insertar_Usuario = (gcnew System::Windows::Forms::Button());
			this->Insertar_Semilla = (gcnew System::Windows::Forms::Button());
			this->Insertar_Parcela = (gcnew System::Windows::Forms::Button());
			this->Registrar_Empresa = (gcnew System::Windows::Forms::Button());
			this->Registrar_Asesor = (gcnew System::Windows::Forms::Button());
			this->Insertar_Consulta = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(134, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(93, 25);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Semillas";
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(48, 37);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(252, 246);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 1;
			this->pictureBox1->TabStop = false;
			// 
			// Insertar_Usuario
			// 
			this->Insertar_Usuario->Location = System::Drawing::Point(64, 47);
			this->Insertar_Usuario->Name = L"Insertar_Usuario";
			this->Insertar_Usuario->Size = System::Drawing::Size(96, 23);
			this->Insertar_Usuario->TabIndex = 2;
			this->Insertar_Usuario->Text = L"Insertar Usuario";
			this->Insertar_Usuario->UseVisualStyleBackColor = true;
			this->Insertar_Usuario->Click += gcnew System::EventHandler(this, &Form1::Insertar_Usuario_Click);
			// 
			// Insertar_Semilla
			// 
			this->Insertar_Semilla->Location = System::Drawing::Point(180, 47);
			this->Insertar_Semilla->Name = L"Insertar_Semilla";
			this->Insertar_Semilla->Size = System::Drawing::Size(105, 23);
			this->Insertar_Semilla->TabIndex = 3;
			this->Insertar_Semilla->Text = L"Insertar Semilla";
			this->Insertar_Semilla->UseVisualStyleBackColor = true;
			this->Insertar_Semilla->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Insertar_Parcela
			// 
			this->Insertar_Parcela->Location = System::Drawing::Point(64, 76);
			this->Insertar_Parcela->Name = L"Insertar_Parcela";
			this->Insertar_Parcela->Size = System::Drawing::Size(96, 23);
			this->Insertar_Parcela->TabIndex = 4;
			this->Insertar_Parcela->Text = L"Insertar Parcela";
			this->Insertar_Parcela->UseVisualStyleBackColor = true;
			this->Insertar_Parcela->Click += gcnew System::EventHandler(this, &Form1::Insertar_Parcela_Click);
			// 
			// Registrar_Empresa
			// 
			this->Registrar_Empresa->Location = System::Drawing::Point(180, 76);
			this->Registrar_Empresa->Name = L"Registrar_Empresa";
			this->Registrar_Empresa->Size = System::Drawing::Size(105, 23);
			this->Registrar_Empresa->TabIndex = 5;
			this->Registrar_Empresa->Text = L"Insertar Empresa";
			this->Registrar_Empresa->UseVisualStyleBackColor = true;
			this->Registrar_Empresa->Click += gcnew System::EventHandler(this, &Form1::Registrar_Empresa_Click);
			// 
			// Registrar_Asesor
			// 
			this->Registrar_Asesor->Location = System::Drawing::Point(64, 105);
			this->Registrar_Asesor->Name = L"Registrar_Asesor";
			this->Registrar_Asesor->Size = System::Drawing::Size(96, 23);
			this->Registrar_Asesor->TabIndex = 6;
			this->Registrar_Asesor->Text = L"Insertar Asesor";
			this->Registrar_Asesor->UseVisualStyleBackColor = true;
			this->Registrar_Asesor->Click += gcnew System::EventHandler(this, &Form1::Registrar_Asesor_Click);
			// 
			// Insertar_Consulta
			// 
			this->Insertar_Consulta->Location = System::Drawing::Point(180, 105);
			this->Insertar_Consulta->Name = L"Insertar_Consulta";
			this->Insertar_Consulta->Size = System::Drawing::Size(105, 23);
			this->Insertar_Consulta->TabIndex = 7;
			this->Insertar_Consulta->Text = L"Insertar Consulta";
			this->Insertar_Consulta->UseVisualStyleBackColor = true;
			this->Insertar_Consulta->Click += gcnew System::EventHandler(this, &Form1::Insertar_Consulta_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(330, 312);
			this->Controls->Add(this->Insertar_Consulta);
			this->Controls->Add(this->Registrar_Asesor);
			this->Controls->Add(this->Registrar_Empresa);
			this->Controls->Add(this->Insertar_Parcela);
			this->Controls->Add(this->Insertar_Semilla);
			this->Controls->Add(this->Insertar_Usuario);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Insertar_Usuario_Click(System::Object^  sender, System::EventArgs^  e) {
				 Form2^ f2 = gcnew Form2();
				 f2-> ShowDialog();
			 }
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 Form3^ f3 = gcnew Form3();
				 f3-> ShowDialog();
			 }
private: System::Void Insertar_Parcela_Click(System::Object^  sender, System::EventArgs^  e) {
			 Form4^ f4 = gcnew Form4();
			 f4-> ShowDialog();
		 }
private: System::Void Registrar_Empresa_Click(System::Object^  sender, System::EventArgs^  e) {
			 Form41^ f41 = gcnew Form41();
			 f41-> ShowDialog();
		 }
private: System::Void Registrar_Asesor_Click(System::Object^  sender, System::EventArgs^  e) {
			 Form5^ f5 = gcnew Form5();
			 f5-> ShowDialog();
		 }
private: System::Void Insertar_Consulta_Click(System::Object^  sender, System::EventArgs^  e) {
			 Form6^ f6 = gcnew Form6();
			 f6-> ShowDialog();
		 }
};
}


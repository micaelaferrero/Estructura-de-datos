#include "StdAfx.h"
#include "Asesores.h"
#include "Persona.h"
#include "Empresa.h"

Asesores::Asesores(void){
}
void Asesores::insertaridAsesor(int c){
	idAsesor = c;
}
int Asesores::devolveridAsesor(){
	return idAsesor;
}
/*
void Asesores::insertarnickName(string n){
	nickName = n;
}
string Asesores::devolvernickName(){
	return nickName;
}*/
void Asesores::insertarcontraAsesor(string ca){
	contraAsesor = ca;
}
string Asesores::devolvercontraAsesor(){
	return contraAsesor;
}
void Asesores::insertarrespSeguridad(string rs){
	respSeguridad = rs;
}
string Asesores::devolverrespSeguridad(){
	return respSeguridad;
}
asesores Asesores::ConvertiraStruct(){
	asesores A;
	char f[30],g[30], h[30], i[30];
	strcpy(f,this->devolverNombrePersona().c_str());
	strcpy(g,this->devolvercontraAsesor().c_str());
	strcpy(A.contraA,g);
	/*strcpy(h,this->devolverrespSeguridad().c_str());
	strcpy(A.respSeguridad,h);
	strcpy(i,this->devolvernickName().c_str());
	strcpy(A.nickname,i);*/
	A.idAsesor = this->devolveridAsesor();
	A.idEmpresa = this->devolveridEmpresa();
	return A;
}


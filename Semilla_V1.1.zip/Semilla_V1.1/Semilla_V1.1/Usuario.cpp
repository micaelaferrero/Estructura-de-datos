#include "StdAfx.h"
#include "Usuario.h"
#include "Persona.h"

Usuario::Usuario(void){
}
void Usuario::insertarCodUsuario(int c){
	CodUsuario = c;
}
int Usuario::devolverCodUsuario(){
	return CodUsuario;
}
void Usuario::insertarnickName(string n){
	nickName = n;
}
string Usuario::devolvernickName(){
	return nickName;
}
void Usuario::insertarcontraUsuario(string cu){
	contraUsuario = cu;
}
string Usuario::devolvercontraUsuario(){
	return contraUsuario;
}
void Usuario::insertarrespSeguridad(string rs){
	respSeguridad = rs;
}
string Usuario::devolverrespSeguridad(){
	return respSeguridad;
}
usuario Usuario::ConvertiraStruct(){
	usuario C;
	char f[30],g[30], h[30], i[30];
	strcpy(f,this->devolverNombrePersona().c_str());
	strcpy(C.nombre,f);
	strcpy(g,this->devolvercontraUsuario().c_str());
	strcpy(C.contraU,g);
	strcpy(h,this->devolverrespSeguridad().c_str());
	strcpy(C.respSeguridad,h);
	strcpy(i,this->devolvernickName().c_str());
	strcpy(C.nickname,i);
	C.idUsuario = this->devolverCodUsuario();
	return C;
}

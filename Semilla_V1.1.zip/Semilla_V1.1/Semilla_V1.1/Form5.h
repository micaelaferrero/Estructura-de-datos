#pragma once
#include <iostream>
#include <string>
#include "Asesores.h"
#include "Empresa.h"
#include "Estructura_Conversion.h"
#include "Clase_Archivo.h"
#include <msclr\marshal_cppstd.h>
namespace Semilla_V11 {
	using namespace msclr::interop;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form5
	/// </summary>
	public ref class Form5 : public System::Windows::Forms::Form
	{
	public:
		Form5(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form5()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txtIdAsesor;
	private: System::Windows::Forms::TextBox^  txtNombreA;
	private: System::Windows::Forms::TextBox^  txtContra;
	private: System::Windows::Forms::TextBox^  txtIdEmpresa;
	private: System::Windows::Forms::DataGridView^  grilla_Asesor;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;
	private: System::Windows::Forms::Button^  Registrar_Asesor;
	private: System::Windows::Forms::Button^  Mostrar_Asesor;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtIdAsesor = (gcnew System::Windows::Forms::TextBox());
			this->txtNombreA = (gcnew System::Windows::Forms::TextBox());
			this->txtContra = (gcnew System::Windows::Forms::TextBox());
			this->txtIdEmpresa = (gcnew System::Windows::Forms::TextBox());
			this->grilla_Asesor = (gcnew System::Windows::Forms::DataGridView());
			this->Registrar_Asesor = (gcnew System::Windows::Forms::Button());
			this->Mostrar_Asesor = (gcnew System::Windows::Forms::Button());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Asesor))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(127, 30);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(39, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Asesor";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(38, 52);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(53, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"ID Asesor";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(38, 78);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Nombre";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(38, 107);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(61, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Contrase�a";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(38, 135);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(62, 13);
			this->label5->TabIndex = 4;
			this->label5->Text = L"ID Empresa";
			// 
			// txtIdAsesor
			// 
			this->txtIdAsesor->Location = System::Drawing::Point(118, 52);
			this->txtIdAsesor->Name = L"txtIdAsesor";
			this->txtIdAsesor->Size = System::Drawing::Size(100, 20);
			this->txtIdAsesor->TabIndex = 5;
			// 
			// txtNombreA
			// 
			this->txtNombreA->Location = System::Drawing::Point(118, 78);
			this->txtNombreA->Name = L"txtNombreA";
			this->txtNombreA->Size = System::Drawing::Size(100, 20);
			this->txtNombreA->TabIndex = 6;
			// 
			// txtContra
			// 
			this->txtContra->Location = System::Drawing::Point(118, 107);
			this->txtContra->Name = L"txtContra";
			this->txtContra->Size = System::Drawing::Size(100, 20);
			this->txtContra->TabIndex = 7;
			// 
			// txtIdEmpresa
			// 
			this->txtIdEmpresa->Location = System::Drawing::Point(118, 135);
			this->txtIdEmpresa->Name = L"txtIdEmpresa";
			this->txtIdEmpresa->Size = System::Drawing::Size(100, 20);
			this->txtIdEmpresa->TabIndex = 8;
			// 
			// grilla_Asesor
			// 
			this->grilla_Asesor->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_Asesor->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {this->Column1, 
				this->Column2, this->Column3, this->Column4});
			this->grilla_Asesor->Location = System::Drawing::Point(305, 30);
			this->grilla_Asesor->Name = L"grilla_Asesor";
			this->grilla_Asesor->Size = System::Drawing::Size(246, 150);
			this->grilla_Asesor->TabIndex = 9;
			// 
			// Registrar_Asesor
			// 
			this->Registrar_Asesor->Location = System::Drawing::Point(24, 202);
			this->Registrar_Asesor->Name = L"Registrar_Asesor";
			this->Registrar_Asesor->Size = System::Drawing::Size(75, 23);
			this->Registrar_Asesor->TabIndex = 10;
			this->Registrar_Asesor->Text = L"Registrar";
			this->Registrar_Asesor->UseVisualStyleBackColor = true;
			this->Registrar_Asesor->Click += gcnew System::EventHandler(this, &Form5::Registrar_Asesor_Click);
			// 
			// Mostrar_Asesor
			// 
			this->Mostrar_Asesor->Location = System::Drawing::Point(269, 201);
			this->Mostrar_Asesor->Name = L"Mostrar_Asesor";
			this->Mostrar_Asesor->Size = System::Drawing::Size(75, 23);
			this->Mostrar_Asesor->TabIndex = 11;
			this->Mostrar_Asesor->Text = L"Mostrar";
			this->Mostrar_Asesor->UseVisualStyleBackColor = true;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"ID Asesor";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Nombre";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Contrase�a";
			this->Column3->Name = L"Column3";
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"ID Empresa";
			this->Column4->Name = L"Column4";
			// 
			// Form5
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(806, 261);
			this->Controls->Add(this->Mostrar_Asesor);
			this->Controls->Add(this->Registrar_Asesor);
			this->Controls->Add(this->grilla_Asesor);
			this->Controls->Add(this->txtIdEmpresa);
			this->Controls->Add(this->txtContra);
			this->Controls->Add(this->txtNombreA);
			this->Controls->Add(this->txtIdAsesor);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form5";
			this->Text = L"Form5";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Asesor))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Registrar_Asesor_Click(System::Object^  sender, System::EventArgs^  e) {
				 Clase_Archivo <asesores> as;
				 Asesores AS;
				 AS.insertaridAsesor(System::Convert::ToInt32(txtIdAsesor->Text));
				 AS.insertarNombrePersona(marshal_as<std::string>(System::Convert::ToString(txtNombreA->Text)));
				 AS.insertarcontraAsesor(marshal_as<std::string>(System::Convert::ToString(txtContra->Text)));
				 AS.insertaridEmpresa(System::Convert::ToInt32(txtIdEmpresa->Text));
				 string cadena = "Asesores";
				 as.ingresar(AS.ConvertiraStruct(),cadena);
				 //AQUI
			 }
};
}

#pragma once
#include <string>
#include <iostream>
using namespace std;
class Persona{
private:
	string nombrePersona;
public:
	Persona(void);
	void insertarNombrePersona(string);
	string devolverNombrePersona();
};


#include "StdAfx.h"
#include "Empresa.h"


Empresa::Empresa(void){
}
void Empresa::insertaridEmpresa(int c){
	idEmpresa = c;
}
int Empresa::devolveridEmpresa(){
	return idEmpresa;
}
void Empresa::insertarnombreEmpresa(string n){
	nombreEmpresa = n;
}
string Empresa::devolvernombreEmpresa(){
	return nombreEmpresa;
}
void Empresa::insertarNIT(int c){
	NIT = c;
}
int Empresa::devolverNIT(){
	return NIT;
}
empresa Empresa::ConvertiraStruct(){
	empresa EM;
	char f[30];
	strcpy(f,this->devolvernombreEmpresa().c_str());
	strcpy(EM.nombreEmpresa,f);
	EM.idEmpresa = this->devolveridEmpresa();
	EM.NIT = this->devolverNIT();
	return EM;
}

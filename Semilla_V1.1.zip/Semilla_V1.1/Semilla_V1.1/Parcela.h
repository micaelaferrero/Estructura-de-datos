#pragma once
#include <string>
#include <iostream>
#include "Usuario.h"
#include "Semilla_Caracteristica.h"
#include "Estructura_Conversion.h"
using namespace std;
class Parcela:public Usuario, public Semilla_Caracteristica{
private:
	int idParcela;
	int area;
	int tiempo;
public:
	Parcela(void);
	void insertaridParcela(int);
	int devolveridParcela();
	void insertararea(int);
	int devolverarea();
	void insertartiempo(int);
	int devolvertiempo();
	parcela ConvertiraStruct();
};


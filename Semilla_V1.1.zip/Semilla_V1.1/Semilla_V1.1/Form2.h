#pragma once
#include <iostream>
#include <string>
#include "Persona.h"
#include "Usuario.h"
#include "Estructura_Conversion.h"
#include "Clase_Archivo.h"
#include <msclr\marshal_cppstd.h>

namespace Semilla_V11 {
	using namespace msclr::interop; //Adicion
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form2
	/// </summary>
	public ref class Form2 : public System::Windows::Forms::Form
	{
	public:
		Form2(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtIdUsuario;
	private: System::Windows::Forms::TextBox^  txtNickname;
	private: System::Windows::Forms::TextBox^  txtNombre;
	private: System::Windows::Forms::TextBox^  txtContra;
	private: System::Windows::Forms::TextBox^  txtResp;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Button^  RegUsuario;
	private: System::Windows::Forms::DataGridView^  grilla_Usuario;
	private: System::Windows::Forms::Button^  mostrar_Usuario;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;




	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtIdUsuario = (gcnew System::Windows::Forms::TextBox());
			this->txtNickname = (gcnew System::Windows::Forms::TextBox());
			this->txtNombre = (gcnew System::Windows::Forms::TextBox());
			this->txtContra = (gcnew System::Windows::Forms::TextBox());
			this->txtResp = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->RegUsuario = (gcnew System::Windows::Forms::Button());
			this->grilla_Usuario = (gcnew System::Windows::Forms::DataGridView());
			this->mostrar_Usuario = (gcnew System::Windows::Forms::Button());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Usuario))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(121, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(86, 25);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Usuario";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(41, 57);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(55, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Id Usuario";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(41, 85);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(55, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Nickname";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(41, 116);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(44, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Nombre";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(41, 142);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(61, 13);
			this->label5->TabIndex = 4;
			this->label5->Text = L"Contrase�a";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(12, 190);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(109, 13);
			this->label6->TabIndex = 5;
			this->label6->Text = L"Respuesta Seguridad";
			// 
			// txtIdUsuario
			// 
			this->txtIdUsuario->Location = System::Drawing::Point(124, 54);
			this->txtIdUsuario->Name = L"txtIdUsuario";
			this->txtIdUsuario->Size = System::Drawing::Size(100, 20);
			this->txtIdUsuario->TabIndex = 6;
			// 
			// txtNickname
			// 
			this->txtNickname->Location = System::Drawing::Point(124, 82);
			this->txtNickname->Name = L"txtNickname";
			this->txtNickname->Size = System::Drawing::Size(100, 20);
			this->txtNickname->TabIndex = 7;
			// 
			// txtNombre
			// 
			this->txtNombre->Location = System::Drawing::Point(124, 109);
			this->txtNombre->Name = L"txtNombre";
			this->txtNombre->Size = System::Drawing::Size(100, 20);
			this->txtNombre->TabIndex = 8;
			// 
			// txtContra
			// 
			this->txtContra->Location = System::Drawing::Point(124, 135);
			this->txtContra->Name = L"txtContra";
			this->txtContra->Size = System::Drawing::Size(100, 20);
			this->txtContra->TabIndex = 9;
			// 
			// txtResp
			// 
			this->txtResp->Location = System::Drawing::Point(127, 187);
			this->txtResp->Name = L"txtResp";
			this->txtResp->Size = System::Drawing::Size(100, 20);
			this->txtResp->TabIndex = 10;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(67, 168);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(131, 13);
			this->label7->TabIndex = 11;
			this->label7->Text = L"�Como se llama tu madre\?";
			// 
			// RegUsuario
			// 
			this->RegUsuario->Location = System::Drawing::Point(44, 232);
			this->RegUsuario->Name = L"RegUsuario";
			this->RegUsuario->Size = System::Drawing::Size(75, 23);
			this->RegUsuario->TabIndex = 12;
			this->RegUsuario->Text = L"Registrar";
			this->RegUsuario->UseVisualStyleBackColor = true;
			this->RegUsuario->Click += gcnew System::EventHandler(this, &Form2::RegUsuario_Click);
			// 
			// grilla_Usuario
			// 
			this->grilla_Usuario->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_Usuario->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {this->Column1, 
				this->Column2, this->Column3, this->Column4});
			this->grilla_Usuario->Location = System::Drawing::Point(304, 53);
			this->grilla_Usuario->Name = L"grilla_Usuario";
			this->grilla_Usuario->Size = System::Drawing::Size(240, 150);
			this->grilla_Usuario->TabIndex = 13;
			// 
			// mostrar_Usuario
			// 
			this->mostrar_Usuario->Location = System::Drawing::Point(370, 231);
			this->mostrar_Usuario->Name = L"mostrar_Usuario";
			this->mostrar_Usuario->Size = System::Drawing::Size(75, 23);
			this->mostrar_Usuario->TabIndex = 14;
			this->mostrar_Usuario->Text = L"Mostrar";
			this->mostrar_Usuario->UseVisualStyleBackColor = true;
			this->mostrar_Usuario->Click += gcnew System::EventHandler(this, &Form2::mostrar_Usuario_Click);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"ID Usuario";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Nickname";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Nombre";
			this->Column3->Name = L"Column3";
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"Contrase�a";
			this->Column4->Name = L"Column4";
			// 
			// Form2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(600, 295);
			this->Controls->Add(this->mostrar_Usuario);
			this->Controls->Add(this->grilla_Usuario);
			this->Controls->Add(this->RegUsuario);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtResp);
			this->Controls->Add(this->txtContra);
			this->Controls->Add(this->txtNombre);
			this->Controls->Add(this->txtNickname);
			this->Controls->Add(this->txtIdUsuario);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form2";
			this->Text = L"Form2";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Usuario))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void RegUsuario_Click(System::Object^  sender, System::EventArgs^  e) {
				 Clase_Archivo <usuario> c;
				 Usuario C;
				 int band,id;
				 string cad = "Usuarios";
				 id = (System::Convert::ToInt32(txtIdUsuario->Text));
				 band = c.buscarID(id,cad);
				 if(band == 0){
				 C.insertarCodUsuario(System::Convert::ToInt32(txtIdUsuario->Text));
				 C.insertarNombrePersona(marshal_as<std::string>(System::Convert::ToString(txtNombre->Text)));
				 C.insertarnickName(marshal_as<std::string>(System::Convert::ToString(txtNickname->Text)));
				 C.insertarcontraUsuario(marshal_as<std::string>(System::Convert::ToString(txtContra->Text)));
				 C.insertarrespSeguridad(marshal_as<std::string>(System::Convert::ToString(txtResp->Text)));
				 string cadena = "Usuarios";
				 c.ingresar(C.ConvertiraStruct(),cadena);
				 }
				 //AQUI
			 }
private: System::Void mostrar_Usuario_Click(System::Object^  sender, System::EventArgs^  e) {
			 Clase_Archivo <usuario> c;
			 usuario C;
			 int i = 0, tam;
			 tam = c.tamano("Usuarios");
			 grilla_Usuario->RowCount = tam;
			 for(i = 0; i < tam; i++){
				 C = c.devolver_reg(i,"Usuarios");
				 grilla_Usuario->Rows[i]->Cells[0]->Value = C.idUsuario;
				 grilla_Usuario->Rows[i]->Cells[1]->Value = marshal_as<System::String^>(C.nombre);
				 grilla_Usuario->Rows[i]->Cells[2]->Value = marshal_as<System::String^>(C.contraU);
				 grilla_Usuario->Rows[i]->Cells[3]->Value = marshal_as<System::String^>(C.respSeguridad);
		 }
		 }
};
}

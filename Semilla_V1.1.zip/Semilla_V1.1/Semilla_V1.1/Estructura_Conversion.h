#pragma once
#include <iostream>
#include <string>
using namespace std;
//IO OK
struct usuario{
	int idUsuario;
	char nickname[30];
	char nombre[30];
	char contraU[30];
	char respSeguridad[30];
};
//IO OK
struct semilla{
	int idSemilla;
	char nombreSemilla[30];
	char caracteristica[30];
};
//IO OK
struct parcela{
	int idParcela;
	int idSemilla;
	int idUsuario;
	int Area;
	int tiempo;
};
//IO OK
struct asesores{
	int idAsesor;
	char nombreAsesor[30];
	char contraA[30];
	int idEmpresa;
	char respSeguridad[30];
};
//IO OK
struct empresa{
	int idEmpresa;
	char nombreEmpresa[30];
	int NIT;
};

/*struct respuesta{
	int idParcela;
	char problema[30];
	char solucion[30];
};*/
struct consulta{
	int idConsulta;
	int idParcela;
	//int idUsuario;
	char problema[100];
};

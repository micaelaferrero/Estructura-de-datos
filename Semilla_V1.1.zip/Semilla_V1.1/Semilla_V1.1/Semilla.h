#pragma once
#include <string>
#include <iostream>
using namespace std;
class Semilla{
private:
	int idSemilla;
	string nombreSemilla;
public:
	Semilla(void);
	void insertaridSemilla(int);
	int devolveridSemilla();
	void insertarnombreSemilla(string);
	string devolvernombreSemilla();
};


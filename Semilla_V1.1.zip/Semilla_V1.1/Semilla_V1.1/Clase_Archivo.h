#pragma once
#include <iostream>
#include <string.h>
using namespace std;
template <class T>
class Clase_Archivo{
public:
	Clase_Archivo(void);
	void ingresar(T archivo , string nom);
	T devolver_reg(int pos, string nom);
	int tamano(string nom);
	int buscarID(int,string);
	T buscar(string c,string a);
	T devolverEmpresa(string n, string empresa);
};
template <class T>
Clase_Archivo<T>::Clase_Archivo(void){
}
template <class T>
void Clase_Archivo<T>::ingresar(T reg, string nom){
	FILE *ptr;
	string cadena;
	cadena = nom +".dat";
	const char* nombre = cadena.c_str();
	ptr = fopen(nombre,"ab");
	fseek(ptr,0,SEEK_END);
	fwrite(&reg,sizeof(reg),1,ptr);
	fclose(ptr);
}
template <class T>
T Clase_Archivo<T>::devolver_reg(int pos, string nom){
	FILE *ptr;
	T reg;
	string cadena;
	cadena = nom +".dat";
	const char* nombre = cadena.c_str();
	ptr = fopen(nombre,"rb");
	fseek(ptr,(pos)*sizeof(reg),SEEK_SET);
	fread(&reg,sizeof(reg),1,ptr);
	fclose(ptr);
	return reg;
}
template<class T>
int Clase_Archivo<T>::buscarID(int id, string a){
	int i = 0, band = 0;
	string j;
	T w;
	j = a+".dat";
	FILE *ptr;
	const char* d=j.c_str();
	ptr=fopen(d,"rb");
	if(ptr!=NULL){
		fread(&w,sizeof(w),1,ptr);
		while(!feof(ptr)){
			if(w.idUsuario == id){
				band = 1;
			}
			fread(&w,sizeof(w),1,ptr);
		}
	}
	return band;
}
template<class T>
T Clase_Archivo<T>::buscar(string c,string a){
	int num=c.lenght();
	i=0;
	string j;
	T w;
	j= a+".dat";
	char v[20];
	while(i<num){
		v[i]=b[i];
		i++;
	}
	v[num]='\0';
	FILE *ptr;
	const char* d=j.c_str();
	ptr=fopen(d,"rb");
	if(ptr!=NULL){
		fread(&w,sizeof(w),1,ptr);
		while(!feof(ptr)==false){
		if(strcmp(v,(w.nombre))==0)
			return w;
		fread(&w,sizeof(w),1,ptr);
		}
	}
}
template <class T>
int Clase_Archivo<T>::tamano(string nom){
	FILE *ptr;
	string cadena;
	T reg;
	int bTotal;
	cadena = nom +".dat";
	const char* nombre = cadena.c_str();
	ptr = fopen(nombre,"rb");
	fseek(ptr,0,SEEK_END);
	bTotal = ftell(ptr)/sizeof(reg);
	fclose(ptr);
	return bTotal;
}
template <class T>
T Clase_Archivo<T>::devolverEmpresa(string n, string empresa){
	FILE *ptr;
	T reg;
	string nom = n+".dat";
	const char* nombre = nom.c_str();
	const char* NE = empresa.c_str();
	ptr = fopen(nombre,"rb");
	fread(&reg,sizeof(reg),1,ptr);
	while(!feof(ptr)){
		if(strcmp(NE,reg.nombreEmpresa)==0){
			fseek(ptr,0,SEEK_END);
		}
		fread(&reg,sizeof(reg),1,ptr);
	}
	fclose(ptr);
	return reg;
}
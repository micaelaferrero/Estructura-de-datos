#include "StdAfx.h"
#include "Caracteristica.h"

Caracteristica::Caracteristica(void){
}
void Caracteristica::insertardetalleCaracteristica(string a){
	detalleCaracteristica = a;
}
string Caracteristica::devolverdetalleCaracteristica(){
	return detalleCaracteristica;
}
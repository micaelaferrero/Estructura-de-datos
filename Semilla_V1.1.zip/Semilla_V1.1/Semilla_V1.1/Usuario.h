#pragma once
#include <string>
#include <iostream>
#include "Persona.h"
#include "Estructura_Conversion.h"
using namespace std;
class Usuario:public Persona{
private:
	int CodUsuario; //LlavePrimaria
	string nickName;
	string contraUsuario;
	string respSeguridad;
public:
	Usuario(void);
	void insertarCodUsuario(int);
	int devolverCodUsuario();
	void insertarnickName(string);
	string devolvernickName();
	void insertarcontraUsuario(string);
	string devolvercontraUsuario();
	void insertarrespSeguridad(string);
	string devolverrespSeguridad();
	usuario ConvertiraStruct();
};
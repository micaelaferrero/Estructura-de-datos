#pragma once
#include <string>
#include <iostream>
#include "Semilla.h"
#include "Caracteristica.h"
#include "Estructura_Conversion.h"
class Semilla_Caracteristica:public Semilla, public Caracteristica{
public:
	Semilla_Caracteristica(void);
	semilla ConvertiraStruct();
};
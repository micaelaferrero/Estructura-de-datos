#pragma once
#include <string>
#include <iostream>
#include "Estructura_Conversion.h"
using namespace std;
class Empresa{
private:
	int idEmpresa;
	string nombreEmpresa;
	int NIT;
public:
	Empresa(void);
	void insertaridEmpresa(int);
	int devolveridEmpresa();
	void insertarnombreEmpresa(string);
	string devolvernombreEmpresa();
	void insertarNIT(int);
	int devolverNIT();
	empresa ConvertiraStruct();
};


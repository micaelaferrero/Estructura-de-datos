#include "StdAfx.h"
#include "Persona.h"


Persona::Persona(void){
}
void Persona::insertarNombrePersona(string n){
	nombrePersona = n;
}
string Persona::devolverNombrePersona(){
	return nombrePersona;
}

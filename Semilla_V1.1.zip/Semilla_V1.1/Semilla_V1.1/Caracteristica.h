#pragma once
#include <string>
#include <iostream>
using namespace std;
class Caracteristica{
private:
	string detalleCaracteristica;
public:
	Caracteristica(void);
	void insertardetalleCaracteristica(string);
	string devolverdetalleCaracteristica();
};


#pragma once
#include <string>
#include <iostream>
#include "Persona.h"
#include "Empresa.h"
#include "Estructura_Conversion.h"
using namespace std;
class Asesores:public Persona,public Empresa{
private:
	int idAsesor;
	//string nickname;
	string contraAsesor;
	string respSeguridad;
public:
	Asesores(void);
	void insertaridAsesor(int);
	int devolveridAsesor();
	/*void insertarnickName(string);
	string devolvernickName();*/
	void insertarcontraAsesor(string);
	string devolvercontraAsesor();
	void insertarrespSeguridad(string);
	string devolverrespSeguridad();
	asesores ConvertiraStruct();
};


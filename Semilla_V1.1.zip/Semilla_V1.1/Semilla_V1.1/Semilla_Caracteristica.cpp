#include "StdAfx.h"
#include "Semilla.h"
#include "Caracteristica.h"
#include "Semilla_Caracteristica.h"
using namespace std;
Semilla_Caracteristica::Semilla_Caracteristica(void){
}
semilla Semilla_Caracteristica::ConvertiraStruct(){
	semilla S;
	char f[30], g[30];
	strcpy(f,this->devolvernombreSemilla().c_str());
	strcpy(S.nombreSemilla,f);
	S.idSemilla = this->devolveridSemilla();
	strcpy(g,this->devolverdetalleCaracteristica().c_str());
	strcpy(S.caracteristica,g);
	return S;
}

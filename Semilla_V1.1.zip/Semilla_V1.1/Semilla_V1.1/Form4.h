#pragma once
#include <iostream>
#include <string>
#include "Semilla_Caracteristica.h"
#include "Usuario.h"
#include "Parcela.h"
#include "Estructura_Conversion.h"
#include "Clase_Archivo.h"
#include <msclr\marshal_cppstd.h>
namespace Semilla_V11 {
	using namespace msclr::interop;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form4
	/// </summary>
	public ref class Form4 : public System::Windows::Forms::Form
	{
	public:
		Form4(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form4()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtidParcela;
	private: System::Windows::Forms::TextBox^  txtidSemilla;
	private: System::Windows::Forms::TextBox^  txtArea;
	private: System::Windows::Forms::TextBox^  txtTiempo;
	private: System::Windows::Forms::TextBox^  txtidUsuario;
	private: System::Windows::Forms::Button^  Registrar_Parcela;
	private: System::Windows::Forms::DataGridView^  grilla_Parcela;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column5;
	private: System::Windows::Forms::Button^  Mostrar_Parcela;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtidParcela = (gcnew System::Windows::Forms::TextBox());
			this->txtidSemilla = (gcnew System::Windows::Forms::TextBox());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->txtTiempo = (gcnew System::Windows::Forms::TextBox());
			this->txtidUsuario = (gcnew System::Windows::Forms::TextBox());
			this->Registrar_Parcela = (gcnew System::Windows::Forms::Button());
			this->grilla_Parcela = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column5 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Mostrar_Parcela = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Parcela))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(127, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(92, 25);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Parcela";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(70, 61);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(57, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"ID Parcela";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(73, 87);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(54, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"ID Semilla";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(91, 113);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(29, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Area";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(78, 136);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(42, 13);
			this->label5->TabIndex = 4;
			this->label5->Text = L"Tiempo";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(73, 162);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(57, 13);
			this->label6->TabIndex = 5;
			this->label6->Text = L"ID Usuario";
			// 
			// txtidParcela
			// 
			this->txtidParcela->Location = System::Drawing::Point(130, 58);
			this->txtidParcela->Name = L"txtidParcela";
			this->txtidParcela->Size = System::Drawing::Size(100, 20);
			this->txtidParcela->TabIndex = 6;
			// 
			// txtidSemilla
			// 
			this->txtidSemilla->Location = System::Drawing::Point(130, 84);
			this->txtidSemilla->Name = L"txtidSemilla";
			this->txtidSemilla->Size = System::Drawing::Size(100, 20);
			this->txtidSemilla->TabIndex = 7;
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(130, 110);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(100, 20);
			this->txtArea->TabIndex = 8;
			// 
			// txtTiempo
			// 
			this->txtTiempo->Location = System::Drawing::Point(130, 133);
			this->txtTiempo->Name = L"txtTiempo";
			this->txtTiempo->Size = System::Drawing::Size(100, 20);
			this->txtTiempo->TabIndex = 9;
			// 
			// txtidUsuario
			// 
			this->txtidUsuario->Location = System::Drawing::Point(130, 159);
			this->txtidUsuario->Name = L"txtidUsuario";
			this->txtidUsuario->Size = System::Drawing::Size(100, 20);
			this->txtidUsuario->TabIndex = 10;
			// 
			// Registrar_Parcela
			// 
			this->Registrar_Parcela->Location = System::Drawing::Point(45, 201);
			this->Registrar_Parcela->Name = L"Registrar_Parcela";
			this->Registrar_Parcela->Size = System::Drawing::Size(75, 23);
			this->Registrar_Parcela->TabIndex = 11;
			this->Registrar_Parcela->Text = L"Registrar";
			this->Registrar_Parcela->UseVisualStyleBackColor = true;
			this->Registrar_Parcela->Click += gcnew System::EventHandler(this, &Form4::Registrar_Parcela_Click);
			// 
			// grilla_Parcela
			// 
			this->grilla_Parcela->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_Parcela->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(5) {this->Column1, 
				this->Column2, this->Column3, this->Column4, this->Column5});
			this->grilla_Parcela->Location = System::Drawing::Point(315, 25);
			this->grilla_Parcela->Name = L"grilla_Parcela";
			this->grilla_Parcela->Size = System::Drawing::Size(344, 150);
			this->grilla_Parcela->TabIndex = 12;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"ID Parcela";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"ID Semilla";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"ID Usuario";
			this->Column3->Name = L"Column3";
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"Area";
			this->Column4->Name = L"Column4";
			// 
			// Column5
			// 
			this->Column5->HeaderText = L"Tiempo";
			this->Column5->Name = L"Column5";
			// 
			// Mostrar_Parcela
			// 
			this->Mostrar_Parcela->Location = System::Drawing::Point(387, 201);
			this->Mostrar_Parcela->Name = L"Mostrar_Parcela";
			this->Mostrar_Parcela->Size = System::Drawing::Size(75, 23);
			this->Mostrar_Parcela->TabIndex = 13;
			this->Mostrar_Parcela->Text = L"Mostrar";
			this->Mostrar_Parcela->UseVisualStyleBackColor = true;
			this->Mostrar_Parcela->Click += gcnew System::EventHandler(this, &Form4::Mostrar_Parcela_Click);
			// 
			// Form4
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(698, 261);
			this->Controls->Add(this->Mostrar_Parcela);
			this->Controls->Add(this->grilla_Parcela);
			this->Controls->Add(this->Registrar_Parcela);
			this->Controls->Add(this->txtidUsuario);
			this->Controls->Add(this->txtTiempo);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->txtidSemilla);
			this->Controls->Add(this->txtidParcela);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form4";
			this->Text = L"Form4";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Parcela))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Registrar_Parcela_Click(System::Object^  sender, System::EventArgs^  e) {
				 Clase_Archivo <parcela> p;
				 Parcela P;
				 P.insertaridParcela(System::Convert::ToInt32(txtidParcela->Text));
				 P.insertaridSemilla(System::Convert::ToInt32(txtidSemilla->Text));
				 P.insertarCodUsuario(System::Convert::ToInt32(txtidUsuario->Text));
				 P.insertararea(System::Convert::ToInt32(txtArea->Text));
				 P.insertartiempo(System::Convert::ToInt32(txtTiempo->Text));
				 string cadena = "Parcelas";
				 p.ingresar(P.ConvertiraStruct(),cadena);
			 }
private: System::Void Mostrar_Parcela_Click(System::Object^  sender, System::EventArgs^  e) {
			 Clase_Archivo <parcela> p;
			 parcela P;
			 int i = 0, tam;
			 tam = p.tamano("Parcelas");
			 grilla_Parcela->RowCount = tam;
			 for(i = 0; i < tam; i++){
				 P = p.devolver_reg(i,"Parcelas");
				 grilla_Parcela->Rows[i]->Cells[0]->Value=P.idParcela;
				 grilla_Parcela->Rows[i]->Cells[1]->Value=P.idSemilla;
				 grilla_Parcela->Rows[i]->Cells[2]->Value=P.idUsuario;
				 grilla_Parcela->Rows[i]->Cells[3]->Value=P.Area;
				 grilla_Parcela->Rows[i]->Cells[4]->Value=P.tiempo;
			 }
		 }
};
}

#include "StdAfx.h"
#include "Semilla.h"

Semilla::Semilla(void){
}
void Semilla::insertaridSemilla(int c){
	idSemilla = c;
}
int Semilla::devolveridSemilla(){
	return idSemilla;
}
void Semilla::insertarnombreSemilla(string nS){
	nombreSemilla = nS;
}
string Semilla::devolvernombreSemilla(){
	return nombreSemilla;
}

#include "StdAfx.h"
#include "Consulta.h"
#include "Parcela.h"
#include "Usuario.h"

Consulta::Consulta(void){
}
void Consulta::insertaridConsulta(int c){
	idConsulta = c;
}
int Consulta::devolveridConsulta(){
	return idConsulta;
}
void Consulta::insertardetalle(string n){
	detalle = n;
}
string Consulta::devolverdetalle(){
	return detalle;
}
consulta Consulta::ConvertiraStruct(){
	consulta P;
	char f[100];
	P.idParcela = this->devolveridParcela();
	P.idConsulta = this->devolveridConsulta();
//	P.idUsuario = this->devolverCodUsuario();
	strcpy(f,this->devolverdetalle().c_str());
	strcpy(P.problema,f);
	return P;
}
#pragma once
#include <iostream>
#include <string>
#include "Consulta.h"
#include "Usuario.h"
#include "Parcela.h"
#include "Estructura_Conversion.h"
#include "Clase_Archivo.h"
#include <msclr\marshal_cppstd.h>
namespace Semilla_V11 {
	using namespace msclr::interop;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form6
	/// </summary>
	public ref class Form6 : public System::Windows::Forms::Form
	{
	public:
		Form6(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form6()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Registrar_Consulta;
	private: System::Windows::Forms::Button^  Mostrar_Consulta;
	protected: 

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtidConsulta;
	private: System::Windows::Forms::TextBox^  txtidParcela;
	private: System::Windows::Forms::TextBox^  txtDetalle;




	private: System::Windows::Forms::DataGridView^  grilla_Consulta;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;


	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Registrar_Consulta = (gcnew System::Windows::Forms::Button());
			this->Mostrar_Consulta = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtidConsulta = (gcnew System::Windows::Forms::TextBox());
			this->txtidParcela = (gcnew System::Windows::Forms::TextBox());
			this->txtDetalle = (gcnew System::Windows::Forms::TextBox());
			this->grilla_Consulta = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Consulta))->BeginInit();
			this->SuspendLayout();
			// 
			// Registrar_Consulta
			// 
			this->Registrar_Consulta->Location = System::Drawing::Point(32, 192);
			this->Registrar_Consulta->Name = L"Registrar_Consulta";
			this->Registrar_Consulta->Size = System::Drawing::Size(75, 23);
			this->Registrar_Consulta->TabIndex = 0;
			this->Registrar_Consulta->Text = L"Registrar";
			this->Registrar_Consulta->UseVisualStyleBackColor = true;
			this->Registrar_Consulta->Click += gcnew System::EventHandler(this, &Form6::Registrar_Consulta_Click);
			// 
			// Mostrar_Consulta
			// 
			this->Mostrar_Consulta->Location = System::Drawing::Point(151, 192);
			this->Mostrar_Consulta->Name = L"Mostrar_Consulta";
			this->Mostrar_Consulta->Size = System::Drawing::Size(75, 23);
			this->Mostrar_Consulta->TabIndex = 1;
			this->Mostrar_Consulta->Text = L"Mostrar";
			this->Mostrar_Consulta->UseVisualStyleBackColor = true;
			this->Mostrar_Consulta->Click += gcnew System::EventHandler(this, &Form6::Mostrar_Consulta_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(121, 31);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(48, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Consulta";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(50, 57);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(62, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"ID Consulta";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(50, 91);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(57, 13);
			this->label3->TabIndex = 4;
			this->label3->Text = L"ID Parcela";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(50, 116);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(51, 13);
			this->label4->TabIndex = 5;
			this->label4->Text = L"Problema";
			// 
			// txtidConsulta
			// 
			this->txtidConsulta->Location = System::Drawing::Point(138, 57);
			this->txtidConsulta->Name = L"txtidConsulta";
			this->txtidConsulta->Size = System::Drawing::Size(100, 20);
			this->txtidConsulta->TabIndex = 6;
			// 
			// txtidParcela
			// 
			this->txtidParcela->Location = System::Drawing::Point(138, 84);
			this->txtidParcela->Name = L"txtidParcela";
			this->txtidParcela->Size = System::Drawing::Size(100, 20);
			this->txtidParcela->TabIndex = 7;
			// 
			// txtDetalle
			// 
			this->txtDetalle->Location = System::Drawing::Point(138, 110);
			this->txtDetalle->Multiline = true;
			this->txtDetalle->Name = L"txtDetalle";
			this->txtDetalle->Size = System::Drawing::Size(100, 55);
			this->txtDetalle->TabIndex = 8;
			// 
			// grilla_Consulta
			// 
			this->grilla_Consulta->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_Consulta->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {this->Column1, 
				this->Column2, this->Column3});
			this->grilla_Consulta->Location = System::Drawing::Point(322, 31);
			this->grilla_Consulta->Name = L"grilla_Consulta";
			this->grilla_Consulta->Size = System::Drawing::Size(240, 150);
			this->grilla_Consulta->TabIndex = 9;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"ID Consulta";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"ID Parcela";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Problema";
			this->Column3->Name = L"Column3";
			// 
			// Form6
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(638, 261);
			this->Controls->Add(this->grilla_Consulta);
			this->Controls->Add(this->txtDetalle);
			this->Controls->Add(this->txtidParcela);
			this->Controls->Add(this->txtidConsulta);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Mostrar_Consulta);
			this->Controls->Add(this->Registrar_Consulta);
			this->Name = L"Form6";
			this->Text = L"Form6";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_Consulta))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Registrar_Consulta_Click(System::Object^  sender, System::EventArgs^  e) {
				 Clase_Archivo <consulta> p;
				 Consulta P;
				 P.insertaridParcela(System::Convert::ToInt32(txtidParcela->Text));
				 P.insertaridConsulta(System::Convert::ToInt32(txtidConsulta->Text));
				 //P.insertarCodUsuario(System::Convert::ToInt32(txtidUsuario->Text));
				 P.insertardetalle(marshal_as<std::string>(System::Convert::ToString(txtDetalle->Text)));
				 string cadena = "Consultas";
				 p.ingresar(P.ConvertiraStruct(),cadena);
			 }
private: System::Void Mostrar_Consulta_Click(System::Object^  sender, System::EventArgs^  e) {
			 Clase_Archivo <consulta> em;
			 consulta Em;
			 int i = 0, tam;
			 tam = em.tamano("Consultas");
			 grilla_Consulta->RowCount = tam;
			 for(i = 0; i < tam; i++){
				 Em = em.devolver_reg(i,"Consultas");
				 grilla_Consulta->Rows[i]->Cells[0]->Value=Em.idConsulta;
				 grilla_Consulta->Rows[i]->Cells[1]->Value=Em.idParcela;
				 grilla_Consulta->Rows[i]->Cells[2]->Value=marshal_as<System::String^>(Em.problema);
			 }
		 }
};
}
